# GCF-400 Auditor v6 — PRC live-scanner failure correction

## Immediate problem fixed

Version 5 attempted to fall back to its basic local PDF reader when the online PDF.js library was blocked. That reader extracted the actual date/weekday entries on page 1 of the 15-page AgLE file, but automatically rejected the whole file because five annex pages were not decodable. The UI consequently displayed `No files could be scanned`.

Version 6 **does not certify unreadable pages** and does not discard reliably extracted entries: it reports **PARTIAL AUDIT** with the exact unreadable page numbers and permits CSV export of the three page-1 MATCH records.

### In this file using the basic reader:

| Status | Finding |
|---|---|
| Page 1 | Tuesday, December 1, 2026 — MATCH |
| Page 1 | Wednesday, December 2, 2026 — MATCH |
| Page 1 | Thursday, December 3, 2026 — MATCH |
| Partial coverage | 10 of 15 pages readable; pages 3 and 12–15 unchecked |

This is a **partial scan**, not a passing whole-document audit. Advanced PDF.js (or a server-side robust PDF processor) is still necessary for full text decoding of the attachment pages.

## GitHub Pages update

1. Extract this archive.
2. Upload everything **inside `GCF400_Auditor_v6/site/`** into your GitHub Pages repository root (alongside `index.html`), overwriting older files. The site root also includes `vendor/README.md`; this is guidance, not the actual library files.
3. Refresh using Ctrl+Shift+R or clear the site's cached storage. Ensure the heading reads **v6**.
4. Upload `AgLE Program December 2026.pdf` and click **Scan documents**. Even if the advanced libraries are blocked, there should be three MATCH records and an explicit PARTIAL AUDIT warning—not `No files could be scanned`.
5. Use **Download full findings CSV** for those three checked rows.

## For full PDF support and annotated PDF export

The v5/v6 advanced PDF parsing requires PDF.js and PDF-lib. The development sandbox does not have internet access to fetch and bundle these external scripts; therefore the ZIP **does not contain** the library bytes. To avoid reliance on CDN access, download and upload three version-pinned JavaScript libraries described in `site/vendor/README.md` into the matching `vendor/` path. The site uses these local files first, with CDN fallback.

When the reader status says **ADVANCED**, retry the PRC file. The advanced logic was checked with a 15-page text-item mock derived from the actual PDF, returning three MATCH findings, but live full-PDF decoding and browser-based annotated export are **not** certified by that mock.

The checked PDF in `examples/` was produced independently of the browser export; it is only an example, not evidence that the online annotation dependencies worked.

## Safety notes

- The original uploaded PDF or DOCX is never overwritten. Export creates new bytes.
- Some PDFs have image-only/scanned pages. OCR is not included.
- Do not infer a complete audit from a partial scan.
- Schedule date-weekday consistency does not establish the intended date of an event or source authenticity.
- Date-pair-only mode intentionally omits unrelated dates with no associated weekday in annexes.
