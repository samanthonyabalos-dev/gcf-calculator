# Version 6 regression evidence

### Actual PRC case

Source: `AgLE Program December 2026.pdf`, 15 pages. The offline parser reproduced the v5 failure: `Incomplete PDF extraction: no accessible text on 5 of 15 pages` (first unavailable page 3). In v6, **10 pages readable, 5 unchecked (3, 12, 13, 14, 15)**. The parser extracted 291 text rows and identified exactly three schedule date-weekday pairs on page 1. `Tuesday December 1`, `Wednesday December 2`, and `Thursday December 3` all returned MATCH.

Browser DOM/action test in headless Chromium with advanced PDF CDN scripts deliberately unavailable:

- Actual PRC file: 3 date-weekday findings, 3 MATCH, 0 MISMATCH, 0 INVALID; prominent PARTIAL AUDIT warning; browser CSV saved and verified to contain exactly the three date rows.
- Original sample annotated PDF: 64 findings (57 MATCH; 7 MISMATCH).
- Original sample annotated DOCX: 64 findings (57 MATCH; 7 MISMATCH).
- Basic PDF annotation export on a separate 64-row classic-xref PDF: generated ZIP contains annotated PDF. PyMuPDF opened the output, found one appended legend page, and compared text of every original page exactly equal.
- DOCX annotation export on a separate 64-row DOCX: generated ZIP contains valid Word document; original paragraphs match.
- No page-script errors in the tested browser flows.

Advanced-reader text-layout mock: 15 PDF page text arrays supplied by independent PyMuPDF extraction of this PRC PDF, passed to PDF.js-compatible test stub. Advanced module grouped 650 line segments over 15 pages, identified the same 3 MATCH records. **A stub is not a real integration test of the external PDF.js/PDF-lib binaries.**

### What is not proven

- Full 15-page decoding in a live browser when PDF.js is loaded from a CDN or local vendor folder. Third-party library scripts were inaccessible in the isolated test environment.
- Complex PDF annotation save in a browser with PDF-lib, which depends on those scripts.
- Accuracy on scanned pages, CMap edge cases, or arbitrary complex files.

For v6, a PARTIAL AUDIT is accurately distinguished from a complete scan, instead of reporting no results or silently treating unseen pages as checked. This is a correctness/safety fix, not a claim of universal PDF support.
