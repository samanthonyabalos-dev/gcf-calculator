from playwright.sync_api import sync_playwright
import pathlib,subprocess,json,time,glob
ROOT=pathlib.Path('/mnt/data/gcf_v6_fix/GCF400_Auditor_v5/site')
SRC=pathlib.Path('/mnt/data/AgLE Program December 2026.pdf')
DOCX=pathlib.Path('/mnt/data/GCF400_Annotated_Sample.docx')
PDF_SIMPLE=pathlib.Path('/mnt/data/GCF400_Annotated_Sample.pdf')
OUT=pathlib.Path('/mnt/data/gcf_v6_fix/test_results');OUT.mkdir(exist_ok=True)
server=None
try:
 time.sleep(0.6)
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
  ctx=browser.new_context(accept_downloads=True)
  # CDN intentionally blocked: must not prevent audits of locally decodable pages
  ctx.route('**/cdnjs.cloudflare.com/**',lambda route:route.abort())
  page=ctx.new_page();errs=[]
  page.on('pageerror',lambda err: errs.append(str(err)))
  import re
  html=(ROOT/'index.html').read_text()
  all_scripts=re.findall(r'<script\b[^>]*>([\s\S]*?)</script>',html,flags=re.I)
  assert len(all_scripts)>=3
  html=re.sub(r'<script\b[^>]*>[\s\S]*?</script>','',html,flags=re.I)
  page.set_content(html,wait_until='domcontentloaded')
  for f in ['jszip.min.js','gcf-engine.js','pdf-enhanced.js','document-audit.js','annotation-export.js']:
   page.add_script_tag(content=(ROOT/f).read_text())
  for inline in all_scripts:
   if inline.strip():page.add_script_tag(content=inline)

  print('ENGINE',page.locator('#pdfEngineStatus').inner_text())
  assert 'BASIC offline fallback' in page.locator('#pdfEngineStatus').inner_text()
  def test_pdf(file,paired=True):
   page.locator('#docPairedOnly').set_checked(paired)
   page.locator('#docFiles').set_input_files(str(file))
   page.locator('#runDocAudit').click()
   page.wait_for_function('() => !document.querySelector("#runDocAudit").disabled',timeout=25000)
   status=page.locator('#docProgress').inner_text()
   stats=page.locator('#docStats').inner_text()
   print('\nFILE',file.name,'\nSTATUS',status[:850],'\nSTATS',stats[:220])
   return status,stats
  status,stats=test_pdf(SRC)
  assert '3 date–weekday findings' in status, status
  assert 'PARTIAL AUDIT' in status and 'UNREADABLE' not in status.upper().split('PARTIAL AUDIT')[0]
  assert 'Matches\n3' in stats
  assert '0' in stats
  preview=page.locator('#docPreview').inner_text()
  assert 'DECEMBER 1, 2026' in preview and 'DECEMBER 3, 2026' in preview
  with page.expect_download(timeout=15000) as ev:
   page.locator('#docExportAll').click()
  dl=ev.value;f=OUT/'PRC_v6_full_audit.csv';dl.save_as(f)
  txt=f.read_text(encoding='utf-8-sig')
  for date in ['DECEMBER 1, 2026','DECEMBER 2, 2026','DECEMBER 3, 2026']:
   assert date in txt
  assert len(txt.splitlines())==4
  page.screenshot(path=str(OUT/'PRC_v6_browser.png'),full_page=True)
  assert not [e for e in errs if 'Uncaught' in e or 'SyntaxError' in e],errs
  status1,stats1=test_pdf(PDF_SIMPLE)
  assert 'document(s) opened' in status1
  status2,stats2=test_pdf(DOCX)
  assert 'document(s) opened' in status2
  from zipfile import ZipFile
  from io import BytesIO
  # Fully supported classical PDF export remains available without CDN.
  native_pdf=pathlib.Path('/mnt/data/gcf_annotation_integrated/tests/fixtures/Administrative_Prose_64.pdf')
  native_docx=pathlib.Path('/mnt/data/gcf_annotation_integrated/tests/fixtures/Administrative_Prose_64.docx')
  for source in [native_pdf,native_docx]:
   st,ss=test_pdf(source)
   assert '64 date–weekday findings' in st
   assert page.locator('#docExportAnnotated').is_enabled()
   with page.expect_download(timeout=30000) as ev:
    page.locator('#docExportAnnotated').click()
   archive=OUT/(source.suffix[1:]+'_verified_annotations.zip')
   ev.value.save_as(archive)
   with ZipFile(archive) as z:
    names=z.namelist()
    print('ARCHIVE',source.suffix,names)
    annotated=[x for x in names if x.startswith('Annotated/') and not x.endswith('/')]
    assert len(annotated)==1
    outbytes=z.read(annotated[0]); (OUT/pathlib.Path(annotated[0]).name).write_bytes(outbytes)
    assert outbytes.startswith(b'%PDF-' if source.suffix=='.pdf' else b'PK\x03\x04')
   if source.suffix=='.pdf':
    import fitz
    sdoc=fitz.open(source); outdoc=fitz.open(stream=outbytes,filetype='pdf')
    assert len(outdoc)==len(sdoc)+1
    for i in range(len(sdoc)):assert sdoc[i].get_text()==outdoc[i].get_text()
    print('PDF Annotated PDF pages',len(outdoc),'source content equal')
   else:
    from docx import Document
    old=Document(source);new=Document(BytesIO(outbytes))
    assert [p.text for p in old.paragraphs]==[p.text for p in new.paragraphs[:len(old.paragraphs)]]
    print('DOCX original paragraphs preserved')
  print('PAGE_ERRORS',errs[:8]);assert not errs,errs
  browser.close()
 print('ALL_BROWSER_TESTS_PASSED')
except Exception as e:
 print('FAIL',repr(e));raise
finally:
 if server:server.terminate();server.wait(timeout=8)
