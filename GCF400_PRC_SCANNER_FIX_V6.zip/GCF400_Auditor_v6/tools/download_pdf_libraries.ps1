# Run from a Windows PowerShell prompt on a machine with Internet access.
$ErrorActionPreference = 'Stop'
$folder = Join-Path $PSScriptRoot '..\site\vendor'
New-Item -ItemType Directory -Force -Path $folder | Out-Null
$items = @{
  'pdf.min.js' = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'
  'pdf.worker.min.js' = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'
  'pdf-lib.min.js' = 'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js'
}
foreach ($entry in $items.GetEnumerator()) {
  $destination = Join-Path $folder $entry.Key
  Invoke-WebRequest -Uri $entry.Value -OutFile $destination
  $length = (Get-Item $destination).Length
  if ($length -lt 50000) { throw "Downloaded $($entry.Key) is suspiciously small ($length bytes); check the URL." }
  Write-Host "Saved $($entry.Key): $length bytes"
}
Write-Host 'Upload site/vendor/*.js to your GitHub Pages repository under vendor/. Then hard-refresh and confirm ADVANCED PDF reader status.'
