# GCF Date–Weekday Consistency Auditor (RSTMF Research Build)

## Purpose and contribution

This web application is a preliminary **batch consistency checker** for structured Gregorian schedules containing both a `Date` and `Recorded Weekday`. The mathematical weekday code comes from the earlier ALBADORA research at Isabel National Comprehensive School and is formalized here as GCF. The individual continuation adds complete-domain verification, GCF-400 cached implementation, record classification, signed weekday discrepancy analysis, and controlled evaluation. This is **not** a new Gregorian weekday theorem and does not authenticate event records.

## Deployment

Upload the files in this folder to the web root (or the `gcf-calculator` GitHub Pages repository) while preserving `gcf-engine.js`, `jszip.min.js`, `sw.js`, `manifest.webmanifest`, and `index.html` together. The page itself works without remote API calls. Service-worker installation requires HTTPS or localhost; direct file opening can have browser-dependent restrictions. Refresh a previously installed site and clear outdated service-worker caches if the older interface persists.

**The public website deliberately DOES NOT show Zeller or competing-method comparisons.** Those exist only in verification tests and the paper.

## Input

* Required headers: `Date` and `Recorded Weekday` (the latter may alternatively be `Weekday`).
* Complete ISO dates: `2026-09-26` (years 1–9999); US `M/D/YYYY` or Excel 1900-system date serials for single dates.
* Unambiguous ISO range: `2026-09-26..2026-09-27` (max 62 inclusive days). Supply corresponding weekdays such as `Saturday-Sunday`.
* Semicolon-separated ISO date lists with semicolon-separated recorded weekdays are accepted when each has equal length.
* CSV, TSV, XLSX first worksheet; original contextual columns remain intact. XLSX files using the Excel **1904 date system** are rejected; convert dates to ISO text before importing.
* Dates/weekday lists that are ambiguous, inconsistent, or unsupported are classified INVALID and require review. Date ranges are limited to prevent accidental massive expansion.

## Outputs

The interface shows source-record and expanded-date counts, MATCH/MISMATCH/INVALID classifications, expected weekday, modular residue, signed shift (`−3` to `+3`), reasons for flags, and review-first results. Full CSV and flagged CSV reports preserve all source columns; XLSX reports are limited to 100,000 expanded rows (browser memory safeguard, **not a demonstrated guaranteed device capacity**). CSV exports are intended for larger workloads. Worksheet formulas in imported text are not executed.

**Interpretation:** a `MATCH` establishes only internal consistency between weekday and Gregorian date. It cannot detect a date shifted by 7 days, identify the original correct event date, establish historical-calendar adoption, or authenticate the source.

## Mathematics

Original: `W ≡ C + Y + M + D (mod 7)`. Cached: `B(r,m) ≡ C+Y+M (mod 7)` and `W ≡ B(r,m)+D (mod 7)` using 4800 `Uint8Array` entries generated once at page initialization. A signed modular discrepancy is computed from `R ≡ W_recorded − W_GCF (mod 7)`.

The arithmetic cache is a general optimization: other valid Gregorian weekday algorithms can build the **same** 4800-entry values. Benchmark times distinguish **implementations**, not mathematical novelty.

## Reproducible tests

On Node.js 22+ run:

```bash
node tests/verify_and_benchmark_2026.js
node --expose-gc --max-old-space-size=2800 tests/stress_current_engine.js
```

The first test verifies all 3,652,059 valid dates across **eight** implementations: standard GCF, cached GCF-400, normalized Zeller, Gauss, Sakamoto, Lewis Carroll, Conway Doomsday, and ordinal-day arithmetic. It benchmarks the same 400,000 dates with four warm-ups and nine timed runs per method. Tests report to `tests/fresh_verification_benchmark.json`.

The second tests classification with 1,510, 10,000, 100,000, 500,000 and 1,000,000 synthetic source rows and saves `tests/stress_current_engine_results.json`. These are **Node.js classifier tests**; they do not measure browser import, browser rendering, downloads, or XLSX export.

`tests/controlled_batch_1510.csv` is an independently labeled synthetic fixture containing 1,440 matching, 60 deliberately mismatched, and 10 invalid records. `tests/archive_previous_version` preserves older engine tests and measurements for provenance only.

## Researchers and comparison methods

The weekday-code foundation is credited to the original 2024 ALBADORA school research of Alvaro, Balading and Culdora, whose work was made available for continuation according to the researcher. Historical-method comparisons (Gauss, Zeller, Carroll, Sakamoto, Doomsday, ordinal-day) appear in the **research paper**, not in the user-facing app.

This work is a research prototype for preliminary date–weekday data-quality screening. It has not been evaluated for institutional adoption, user time saving, or comparative usability against Excel.
