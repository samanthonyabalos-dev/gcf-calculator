# Controlled input data, independently generated from Python's proleptic Gregorian datetime.
import csv,random
from datetime import date
from pathlib import Path
r=random.Random(1062026)
out=Path(__file__).parent/'controlled_batch_1510.csv'
rows=[]
for i in range(1500):
    y=r.randint(1,9999);m=r.randint(1,12)
    while True:
        try: d=date(y,m,r.randint(1,31));break
        except ValueError: pass
    weekday=d.strftime('%A')
    is_bad=i>=1440
    if is_bad:
        weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][(d.weekday()+2)%7]
    rows.append([d.isoformat(),weekday, f'Controlled record {i+1}', 'Intentionally altered' if is_bad else 'Reference'])
invalid=['2024-02-30','1900-02-29','0000-01-01','10000-01-01','2026-04-31','2026-13-03','2025-02-29','2001-02-29','2024-00-10','2023-11-31']
for k,v in enumerate(invalid):rows.append([v,'Wednesday',f'Invalid fixture {k+1}','Invalid'])
with open(out,'w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['Date','Recorded Weekday','Event','Source Label']);w.writerows(rows)
print(out,len(rows))
