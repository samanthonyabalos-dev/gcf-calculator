// Reproducible stress harness: exact parser, validator, and XLSX exporter extracted unchanged from distributed index.html.
'use strict';
const fs=require('fs');const path=require('path');const {performance}=require('perf_hooks');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]);
const core=scripts[0].split('function moneyless(n)')[0];
const batch=scripts[1];
const first=batch.indexOf('  function parseDateParts(value){'), last=batch.indexOf('  function renderBatchResults(data){');
const excelStart=batch.indexOf('  function sheetXml(rows, styleFn){'),excelEnd=batch.indexOf('  document.getElementById("batchFile").addEventListener');
if([first,last,excelStart,excelEnd].some(x=>x<0)) throw Error('Stress harness unable to find actual app functions');
const JSZip=require(path.join(root,'jszip.min.js'));
const code=core+'\nconst batchState={rows:[],matrix:null,header:null,dateIdx:-1,dayIdx:-1};\n'+batch.slice(batch.indexOf('  function xmlEsc(v){'),last)+'\n'+ batch.slice(excelStart,excelEnd)+'\nreturn {parseDelimited,rowsToBatch,validateBatchRows,buildXlsx,sheetXml,xmlEsc,batchState};';
const api=new Function('performance','JSZip',code)(performance,JSZip);
const days=JSON.parse(fs.readFileSync(path.join(__dirname,'stress_dates_2024.json'),'utf8'));
const n=Number(process.argv[2]);const doExcel=process.argv[3]==='xlsx';
if(!Number.isInteger(n)||n<1) throw Error('invalid size');
const out={size:n,mode:doExcel?'csv_plus_xlsx':'csv_only',node:process.version,platform:process.platform,arch:process.arch,status:'IN_PROGRESS',stages:{}};
function mem(){const m=process.memoryUsage();return {rss_mib:Math.round(m.rss/1048576*10)/10,heap_used_mib:Math.round(m.heapUsed/1048576*10)/10,heap_total_mib:Math.round(m.heapTotal/1048576*10)/10,external_mib:Math.round(m.external/1048576*10)/10};}
let peakRss=0;function stage(label,ms){const memory=mem();peakRss=Math.max(peakRss,memory.rss_mib);out.stages[label]={ms:Math.round(ms*10)/10,...memory};}
(async()=>{
try{
 const t0=performance.now(), header='Date,Recorded Weekday,Event\r\n',chunks=[header];
 for(let i=1;i<=n;i++){
  const [d,w]=days[(i-1)%366];
  const bad=(i%500===0),wrong=(i%100===0&&!bad);
  let dw=w;
  if(wrong){const order=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];dw=order[(order.indexOf(w)+1)%7];}
  chunks.push(`${bad?'2024-02-30':d},${dw},Event ${i}\r\n`);
 }
 let input=chunks.join('');chunks.length=0;
 stage('fixture_generation',performance.now()-t0);out.input_bytes=Buffer.byteLength(input,'utf8');
 let t=performance.now();const matrix=api.parseDelimited(input);input='';stage('csv_parse',performance.now()-t);
 t=performance.now();const rows=api.rowsToBatch(matrix);stage('rows_materialization',performance.now()-t);
 t=performance.now();const result=api.validateBatchRows(rows);stage('batch_classification',performance.now()-t);
 const expected={matches:n-Math.floor(n/100),mismatches:Math.floor(n/100)-Math.floor(n/500),invalid:Math.floor(n/500)};
 const actual={matches:result.matches,mismatches:result.mismatches,invalid:result.invalid};
 if(JSON.stringify(expected)!==JSON.stringify(actual))throw Error(`Classification mismatch expected ${JSON.stringify(expected)} actual ${JSON.stringify(actual)}`);
 out.expected=expected;out.observed=actual;out.application_reported_calculation_ms=Math.round(result.calculationMs*10)/10;
 t=performance.now();const flagged=result.result.filter(r=>r.status!=='MATCH');stage('filter_flagged',performance.now()-t);
 const csvHead=[...api.batchState.header,'GCF Expected Day','Status','Validation Note'];
 t=performance.now();const csvOut=[csvHead.map(s=>String(s)).join(',')];
 for(const r of result.result){const base=r.original.slice();while(base.length<csvHead.length-3)base.push('');base.push(r.gcf,r.status,r.reason||'');csvOut.push(base.map(s=> {const x=String(s??'');return /[",\r\n]/.test(x)?'"'+x.replace(/"/g,'""')+'"':x;}).join(','));}
 let csvStr='\uFEFF'+csvOut.join('\r\n');csvOut.length=0;
 stage('csv_report_generation',performance.now()-t);
 out.csv_report_bytes=Buffer.byteLength(csvStr,'utf8');
 out.csv_record_lines=csvStr.split('\r\n').length-1;
 if(out.csv_record_lines!==n)throw Error('CSV report rows missing');
 csvStr='';
 if(doExcel){
    const summary=[['GCF Batch Validation Summary',''],['Total records',n],['Matches',actual.matches],['Mismatches',actual.mismatches],['Invalid',actual.invalid]];
    t=performance.now();
    const blob=await api.buildXlsx(result.result,summary,flagged);
    stage('xlsx_report_generation',performance.now()-t);
    out.xlsx_report_bytes=blob.size;
    // Validate ZIP and number of worksheet rows to ensure output completeness.
    if(n<=500000){
      t=performance.now();const ab=await blob.arrayBuffer();const zip=await JSZip.loadAsync(Buffer.from(ab),{checkCRC32:true});
      const sheet=await zip.file('xl/worksheets/sheet1.xml').async('string');
      const flaggedSheet=await zip.file('xl/worksheets/sheet3.xml').async('string');
      out.xlsx_verified_rows=(sheet.match(/<row\s+r="/g)||[]).length-1;
      out.xlsx_flagged_rows=(flaggedSheet.match(/<row\s+r="/g)||[]).length-1;
      if(out.xlsx_verified_rows!==n||out.xlsx_flagged_rows!==flagged.length)throw Error('Export incomplete');
      stage('xlsx_zip_integrity_and_row_check',performance.now()-t);
    }
 }
 out.status='PASS';out.total_elapsed_ms=Object.values(out.stages).reduce((s,x)=>s+x.ms,0);out.peak_sampled_rss_mib=peakRss;
 console.log(JSON.stringify(out));
}catch(e){out.status='FAIL';out.error=String(e?.stack||e);out.peak_sampled_rss_mib=peakRss;console.log(JSON.stringify(out));process.exitCode=1;}
})();
