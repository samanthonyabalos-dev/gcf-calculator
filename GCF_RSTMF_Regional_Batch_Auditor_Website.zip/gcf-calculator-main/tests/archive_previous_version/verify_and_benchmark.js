// Research reproducibility. Run: node tests/verify_and_benchmark.js
// Loads the EXACT GCF implementations that the shipped index.html uses.
const fs=require('fs');
const path=require('path');
const {performance}=require('perf_hooks');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const m=html.match(/<script>([\s\S]*?)<\/script>/);
if(!m)throw Error('Application math script not found');
const code=m[1].split('function moneyless(n)')[0];
const math=new Function(code+'\nreturn {calcGCF,zeller,sakamoto,gregorianOrdinalWeekday,gcf400Weekday,validDate,isLeap,centuryCode,COMMON,LEAP};')();
const {calcGCF,zeller,sakamoto,gregorianOrdinalWeekday,gcf400Weekday,isLeap}=math;
function fixedMonthLen(y,m){return m===2?(isLeap(y)?29:28):[4,6,9,11].includes(m)?30:31;}
const cases=[];let matches={zeller:0,sakamoto:0,ordinal:0,cached:0};let mismatch=[];let count=0;
const started=performance.now();
for(let y=1;y<=9999;y++)for(let m=1;m<=12;m++)for(let d=1;d<=fixedMonthLen(y,m);d++){
 const g=calcGCF(y,m,d).W;
 const values={zeller:zeller(y,m,d).zg,sakamoto:sakamoto(y,m,d),ordinal:gregorianOrdinalWeekday(y,m,d),cached:gcf400Weekday(y,m,d)};
 for(const [name,v] of Object.entries(values)){
   if(g===v)matches[name]++;else if(mismatch.length<20)mismatch.push({name,y,m,d,g,v});
 }
 count++;
}
console.log(JSON.stringify({kind:'full_domain',count,matches,mismatch,ms:Number((performance.now()-started).toFixed(1))}));
if(count!==3652059||mismatch.length>0||Object.values(matches).some(n=>n!==count))process.exitCode=1;
const samples=[];let seed=20261023;
function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;}
for(let i=0;i<200000;i++){
 let y=Math.floor(rand()*9999)+1,m=Math.floor(rand()*12)+1,d=Math.floor(rand()*fixedMonthLen(y,m))+1;
 samples.push([y,m,d]);
}
function standardGcfScalar(y,m,d){
 const c=Math.floor(y/100), yy=y%100;
 return (math.centuryCode(c) + yy + Math.floor(yy/4) +
    (isLeap(y)?math.LEAP:math.COMMON)[m-1] + d)%7;
}
const funcs={
 'Original GCF (full)':(y,m,d)=>calcGCF(y,m,d).W,
 'Original GCF (scalar)':standardGcfScalar,
 'GCF-400 cached':gcf400Weekday,
 'Zeller':(y,m,d)=>zeller(y,m,d).zg,
 'Sakamoto':sakamoto,
 'Ordinal-day reference':gregorianOrdinalWeekday
};
// Warmup and measured passes, same exact dates, same Node process.
for(const f of Object.values(funcs))for(let i=0;i<50000;i++){const x=samples[i];f(x[0],x[1],x[2]);}
let benchmark=[];
for(const [name,f] of Object.entries(funcs)){
 const times=[];let checksum=0;
 for(let k=0;k<7;k++){
  const start=performance.now(); let sum=0;
  for(const [y,m,d] of samples)sum+=f(y,m,d);
  const ms=performance.now()-start;
  checksum=sum;times.push(ms);
 }
 times.sort((a,b)=>a-b);
 benchmark.push({name,median_ms:Number(times[3].toFixed(2)),dates:200000,checksum});
}
console.log(JSON.stringify({kind:'node_arithmetic_benchmark',environment:{node:process.version,platform:process.platform,arch:process.arch},results:benchmark}));
