'use strict';
const fs=require('fs'),E=require('../gcf-engine.js'),{performance}=require('perf_hooks');
const sampleSizes=[1510,10000,100000,500000,1000000];
const out={runtime:process.version,platform:process.platform,arch:process.arch,tests:[]};
for(const n of sampleSizes){let rows=[['Date','Recorded Weekday','Event']],expected={MATCH:0,MISMATCH:0,INVALID:0};for(let i=0;i<n;i++){
 const year=2020+i%7,mon=1+i%12,day=1+i%28,date=E.iso(year,mon,day),g=E.gcf400(year,mon,day);
 if(i%500===0){rows.push(['2026-02-30','Monday','Invalid-'+i]);expected.INVALID++;}
 else if(i%125===0){rows.push([date,E.DAYS[(g+1)%7],'Mismatch-'+i]);expected.MISMATCH++;}
 else{rows.push([date,E.DAYS[g],'Match-'+i]);expected.MATCH++;}}
 const t0=performance.now();const data=E.validateMatrix(rows);const t1=performance.now();const ok=JSON.stringify(data.counts)===JSON.stringify(expected);
 const mem=process.memoryUsage();out.tests.push({n,ms:Number((t1-t0).toFixed(3)),correct:ok,counts:data.counts,rss_mib:Number((mem.rss/1048576).toFixed(1)),heap_mib:Number((mem.heapUsed/1048576).toFixed(1))});console.log(out.tests.at(-1));if(!ok)process.exitCode=2;
 rows=null;global.gc&&global.gc();}
fs.writeFileSync(__dirname+'/stress_current_engine_results.json',JSON.stringify(out,null,2));
