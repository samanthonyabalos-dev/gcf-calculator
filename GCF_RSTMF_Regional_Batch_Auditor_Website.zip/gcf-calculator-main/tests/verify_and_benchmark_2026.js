'use strict';
const fs=require('fs'),path=require('path'),perf=require('perf_hooks').performance;
const E=require('../gcf-engine.js');
const implementations=[['GCF standard',(y,m,d)=>E.gcf(y,m,d).W],['GCF-400 cached',E.gcf400],['Zeller normalized',E.zeller],['Gauss',E.gauss],['Sakamoto',E.sakamoto],['Lewis Carroll',E.carroll],['Conway Doomsday',E.doomsday],['Gregorian ordinal-day',E.ordinal]];
function median(a){const b=a.slice().sort((x,y)=>x-y);return b[Math.floor(b.length/2)];}
let tested=0,mismatches={};for(let [name] of implementations)mismatches[name]=0;
for(let y=1;y<=9999;y++)for(let m=1;m<=12;m++){const last=[31,E.isLeap(y)?29:28,31,30,31,30,31,31,30,31,30,31][m-1];for(let d=1;d<=last;d++){
  tested++;const expected=E.ordinal(y,m,d);for(const [name,fn] of implementations)if(fn(y,m,d)!==expected)mismatches[name]++;
}}
const inputs=[],size=400000;
for(let i=0;i<size;i++){const y=1+((i*37+829)%9999),m=1+(i*7%12),max=[31,E.isLeap(y)?29:28,31,30,31,30,31,31,30,31,30,31][m-1],d=1+((i*13)%max);inputs.push([y,m,d]);}
let sink=0;function trial(fn){let s=0;const t=perf.now();for(let i=0;i<inputs.length;i++){const a=inputs[i];s+=fn(a[0],a[1],a[2]);}const delta=perf.now()-t;sink+=s;return delta;}
// A prebuilt cached baseline for another algorithm is mathematically the same table;
// benchmark parity is established by table equality rather than pretending distinct lookup costs.
let cacheParity=true;for(let r=0;r<400;r++)for(let m=1;m<=12;m++){const y=r||400;if(E.gcf400(y,m,1)!==E.gauss(y,m,1)||E.gcf400(y,m,1)!==E.sakamoto(y,m,1))cacheParity=false;}
const result=[];
for(const [name,fn] of implementations){for(let i=0;i<4;i++)trial(fn);let timings=[];for(let i=0;i<9;i++)timings.push(trial(fn));result.push({name,median_ms:Number(median(timings).toFixed(4)),min_ms:Number(Math.min(...timings).toFixed(4)),max_ms:Number(Math.max(...timings).toFixed(4)),runs:9});}
const controlled=fs.readFileSync(path.join(__dirname,'controlled_batch_1510.csv'),'utf8');const controlledRes=E.validateMatrix(E.parseDelimited(controlled));
const rangeRes=E.validateMatrix(E.parseDelimited('Date,Recorded Weekday,Event\n2026-09-26..2026-09-27,Saturday-Sunday,Two-day fixture\n2026-09-27,Monday,Offset fixture\n2026-02-30,Monday,Invalid fixture'));
const out={generated_utc:new Date().toISOString(),date_domain:'1–9999 CE proleptic Gregorian',dates_tested:tested,weekday_mismatches:mismatches,cache_parity_with_gauss_and_sakamoto:cacheParity,benchmark:{runtime:process.version,platform:process.platform,arch:process.arch,device:'Current execution environment; not a browser benchmark',dates_per_run:size,warmup_runs:4,timed_runs:9,order:'fixed, not randomized',note:'Arithmetic only; excludes parsing, export, rendering, and cache generation. Results are environment-specific.',implementations:result,sink},controlled:{source_records:controlledRes.sourceRecords,expanded_records:controlledRes.expandedRecords,counts:controlledRes.counts},range_fixture:{source_records:rangeRes.sourceRecords,expanded_records:rangeRes.expandedRecords,counts:rangeRes.counts,shifts:rangeRes.shifts}};
fs.writeFileSync(path.join(__dirname,'fresh_verification_benchmark.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
if(tested!==3652059||Object.values(mismatches).some(x=>x!==0)||!cacheParity||controlledRes.counts.MATCH!==1440||controlledRes.counts.MISMATCH!==60||controlledRes.counts.INVALID!==10||rangeRes.counts.MATCH!==2||rangeRes.counts.MISMATCH!==1||rangeRes.counts.INVALID!==1)process.exitCode=2;
