GCF Regional Final

The ZIP is the website package only.

Open gcf-calculator-main/index.html.
Upload an .xlsx or .csv file with Date and Recorded Weekday.
Click Validate Batch.
Then:
- Export Annotated Excel -> real .xlsx validation report
- Download CSV -> real .csv validation report
- Download Mismatches CSV -> .csv containing non-MATCH rows

The Excel report contains Validated Records, Summary, and Mismatches.
