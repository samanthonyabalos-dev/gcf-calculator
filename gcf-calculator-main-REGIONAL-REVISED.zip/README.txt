GCF Regional Web Application

Batch validator workflow:
1. Upload an Excel (.xlsx) or CSV file, or paste spreadsheet rows.
2. Required columns: Date and Recorded Weekday. Other columns such as Event/Notes are retained.
3. Validate the batch.
4. Review MATCH, MISMATCH, and INVALID classifications.
5. Export a real Excel workbook (.xlsx) containing Validated Records, Summary, and Mismatches.

The workbook does not silently correct records. A MISMATCH means the recorded weekday disagrees with GCF under the stated proleptic-Gregorian framework; human/source review is required.

The Excel export is a newly generated annotated workbook. It retains the input data values and adds GCF Expected Day, Status, and Validation Note; it does not preserve the source workbook's original Excel formatting, formulas, merges, or extra worksheets.
